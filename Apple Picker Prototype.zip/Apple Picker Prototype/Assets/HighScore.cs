﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HighScore : MonoBehaviour {
    //Making score public and static gives you the ability to access it from any other script by using HighScore.score
    //does NOT reset when the game restarts due to being static
    static public int score = 100;

    //executes when the class is created. Takes priority over Start() and Update()
    void Awake()
    {
        //If the PlayerPrefs HighScore already exists, read it
        if (PlayerPrefs.HasKey("HighScore"))
        {
            score = PlayerPrefs.GetInt("HighScore");
        }
        //Assign the high score to HighScore
        PlayerPrefs.SetInt("HighScore", score);
    }

    // Update is called once per frame
    void Update () {
        Text gt = this.GetComponent<Text>();
        gt.text = "High Score: " + score;

        //Update the PlayerPrefs HighScore if necessary
        if (score > PlayerPrefs.GetInt("HighScore"))
        {
            PlayerPrefs.SetInt("HighScore", score);
        }
	}
}
